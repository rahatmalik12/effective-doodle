document.addEventListener("DOMContentLoaded", () => {
  const validKeys = ["A", "G", "D", "X"];

  function playSound(key) {
    key = key.toUpperCase();
    if (!validKeys.includes(key)) return;

    const audio = document.getElementById(`sound-${key}`);
    const button = document.querySelector(`.drum-button[data-key="${key}"]`);

    if (audio && button) {
      audio.currentTime = 0;
      audio.play();
      button.classList.add("active");
      setTimeout(() => button.classList.remove("active"), 150);
    }
  }

  document.addEventListener("keydown", (e) => {
    if (validKeys.includes(e.key.toUpperCase())) {
      playSound(e.key);
    }
  });

  document.querySelectorAll(".drum-button").forEach(button => {
    button.addEventListener("click", () => {
      playSound(button.getAttribute("data-key"));
    });
  });
});
